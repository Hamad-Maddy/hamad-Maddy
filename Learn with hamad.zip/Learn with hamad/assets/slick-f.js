    $(document).ready(function(){
      $('.our-work-portfolio').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
      });
    });